<?php namespace App\SupportedApps\ISPConfig;

class ISPConfig extends \App\SupportedApps {

}