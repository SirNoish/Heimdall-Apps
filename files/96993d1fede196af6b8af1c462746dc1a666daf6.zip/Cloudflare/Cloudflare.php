<?php namespace App\SupportedApps\Cloudflare;

class Cloudflare extends \App\SupportedApps {

}