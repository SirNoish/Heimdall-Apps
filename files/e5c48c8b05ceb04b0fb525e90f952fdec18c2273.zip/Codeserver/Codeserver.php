<?php namespace App\SupportedApps\Codeserver;

class Codeserver extends \App\SupportedApps {

}