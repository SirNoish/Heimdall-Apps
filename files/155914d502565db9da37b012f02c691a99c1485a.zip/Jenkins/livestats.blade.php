<ul class="livestats">
    <li>
        <span class="title">Running Jobs</span>
        <strong>{!! $TotalRunningJobs !!}</strong>
    </li>
</ul>
