<?php namespace App\SupportedApps\crowdsec;

class crowdsec extends \App\SupportedApps {

}