<?php namespace App\SupportedApps\Gotify;

class Gotify extends \App\SupportedApps
{
}
