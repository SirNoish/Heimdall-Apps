<?php namespace App\SupportedApps\TinyTinyRSS;

class TinyTinyRSS extends \App\SupportedApps {

}