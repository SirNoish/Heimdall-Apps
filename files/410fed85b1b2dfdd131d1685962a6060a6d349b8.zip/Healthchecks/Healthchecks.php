<?php namespace App\SupportedApps\Healthchecks;

class Healthchecks extends \App\SupportedApps {

}