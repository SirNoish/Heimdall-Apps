<?php namespace App\SupportedApps\Dozzle;

class Dozzle extends \App\SupportedApps {

}