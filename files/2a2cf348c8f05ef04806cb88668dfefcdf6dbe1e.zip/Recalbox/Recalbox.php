<?php namespace App\SupportedApps\Recalbox;

class Recalbox extends \App\SupportedApps
{
}
