<?php namespace App\SupportedApps\SonarQube;

class SonarQube extends \App\SupportedApps
{
}
