<?php namespace App\SupportedApps\Photoview;

class Photoview extends \App\SupportedApps
{
}
