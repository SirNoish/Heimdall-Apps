<?php namespace App\SupportedApps\Atlantis;

class Atlantis extends \App\SupportedApps {

}