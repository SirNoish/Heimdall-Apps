<?php namespace App\SupportedApps\Rclone;

class Rclone extends \App\SupportedApps
{
}
