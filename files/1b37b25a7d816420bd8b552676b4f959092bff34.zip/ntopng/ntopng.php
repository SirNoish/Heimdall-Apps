<?php namespace App\SupportedApps\ntopng;

class ntopng extends \App\SupportedApps {

}