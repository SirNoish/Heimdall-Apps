<?php namespace App\SupportedApps\PartKeepr;

class PartKeepr extends \App\SupportedApps
{
}
