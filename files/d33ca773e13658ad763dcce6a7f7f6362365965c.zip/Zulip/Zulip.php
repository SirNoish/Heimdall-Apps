<?php namespace App\SupportedApps\Zulip;

class Zulip extends \App\SupportedApps {

}