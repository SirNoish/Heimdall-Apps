<?php namespace App\SupportedApps\Icecast;

class Icecast extends \App\SupportedApps {

}