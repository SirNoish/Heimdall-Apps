<ul class="livestats">
    <li><span class="title">{!! $left['title'] !!}</span><strong>{!! $left['data'] !!}<span>/{!! $left['total'] !!}</span></strong>
    </li>
    <li><span class="title">{!! $right['title'] !!}</span><strong>{!! $right['data'] !!}<span>/{!! $right['total'] !!}</span></strong>
    </li>
</ul>
