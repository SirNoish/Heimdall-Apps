<?php namespace App\SupportedApps\PeerTube;

class PeerTube extends \App\SupportedApps {

}