<?php namespace App\SupportedApps\Gogs;

class Gogs extends \App\SupportedApps {

}