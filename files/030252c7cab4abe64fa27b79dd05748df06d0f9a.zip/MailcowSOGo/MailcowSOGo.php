<?php namespace App\SupportedApps\MailcowSOGo;

class MailcowSOGo extends \App\SupportedApps {

}